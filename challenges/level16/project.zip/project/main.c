// THIS FILE IS NOT IMPORTANT FOR SOLVING THE CHALLENGE
#include <stdio.h>
int main() {
   printf("Hello, World!");
   return 0;
}